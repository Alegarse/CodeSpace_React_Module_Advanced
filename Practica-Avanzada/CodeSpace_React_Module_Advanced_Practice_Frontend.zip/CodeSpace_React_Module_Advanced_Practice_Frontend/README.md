# Práctica final del módulo de ReactJS🚀 
En este repositorio se desarrolla la práctica final del módulo de ReactJS, de una temática de tienda de Donuts, configurada como un expositor de los productos.   

---
[![My Skills](https://skillicons.dev/icons?i=html,css,js,react,nodejs,mongodb,git,github,vscode)](https://skillicons.dev)
---

---
 
<p align="center">
  <img src="src/assets/Home.PNG" alt="Visualización en navegador del proyecto" width="550">
</p> 

## Tabla de Contenidos📋  
- [Sobre la práctica](#sobre-la-practica)  
- [Tecnologías y Herramientas](#tecnologías-y-herramientas)  
- [Contacto](#contacto)  

---
<a id="sobre-la-practica"></a>
## Sobre la práctica 🌟
Para la realización de esta práctica, se ha realizado a la par un proyecto Front y uno Back, en React y nodeJs respectivamente. Además, se han configurado modelos para usar BBDD no relacional, en este caso MongoDB.   
Por cuestiones de tiempo disponible no se han usado frames de estilos, sinó que se han creado manualmente con CSS.   
A la hora de manejar los datos se ha usado Redux, de forma que se ha distribuido todo el proyecto en compoenntes y pages, reutilizando componentes para optimizar el ciclo de la navegación.   

### **Requisitos**   
Deben tenerse instalados NodeJS y MongoDB, y con ambos en las variables de entoeno para poder lanzar la aplicación.   

### **Despliege de la práctica**   
Para ambos proyectos se deben instalar las dependencias con el comando "npm i" y acto seguido lanzarlas con el comando "npm run dev".   
A la hora de la creación de la BBDD, se realiza automaticamente por mongoose desde el back.   


---
<a id="tecnologías-y-herramientas"></a>
## Tecnologías y Herramientas 🛠️  
Se han usado las siguientes tecnologías y herramientas:  

### **Frontend**  
- 🖌️ **HTML5, CSS3**  
- 🎨 **JavaScript**  
- ⚛️ **React.js** 

### **Backend**  
- 🔧 **Node.js**  
- 🗄️ **MongoDB**  

### **Otros**  
- 🖥️ **Git, GitHub**  
- 🧪 **VSCode**    
   
      
   ---
<a id="contacto"></a>
## Contacto 📞    

- ✉️ **Autor:** Alejandro García Serrano
- ✉️ **Correo:** [agscm2@gmail.com](mailto:agscm2@gmail.com)
- 💼 **LinkedIn:** <a href="https://www.linkedin.com/in/alegarse/" target="_blank">alegarse</a>  

---

<p align="center">✨"El aprendizaje nunca se detiene, y cada línea de código es un paso más hacia el progreso."✨</p> 
