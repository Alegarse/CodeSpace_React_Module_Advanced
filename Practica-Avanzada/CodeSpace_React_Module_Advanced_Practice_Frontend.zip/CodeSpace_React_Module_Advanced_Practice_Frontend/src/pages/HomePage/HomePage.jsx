import React from 'react';
import MenuComponent from '../../components/MenuComponent/MenuComponent';
import { useSelector } from 'react-redux';
import img_homepage from '../../assets/img_homepage.png';
import DonutCreatePage from '../DonutCreatePage/DonutCreatePage';
import ContactPage from '../ContactPage/ContactPage';
import FooterComponent from '../../components/FooterComponent/FooterComponent';
import ListingComponent from '../../components/ListingComponent/ListingComponent';
import ShowInfoPageComponent from '../ShowInfoPage/ShowInfoPageComponent';

const HomePage = () => {
  const menuOptionSelected = useSelector(
    (state) => state.menuComponentReducer.menuOption
  );
  return (
    <div className="home-container">
      <div>
        <MenuComponent />
      </div>
      {menuOptionSelected === 0 ? (
        <DonutCreatePage />
      ) : menuOptionSelected === 1 ? (
        <ShowInfoPageComponent/>
      ) : menuOptionSelected === 2 ? (
        <ContactPage />
      ) : (
        <div className="content-homepage">
          <img
            className="home-img"
            src={img_homepage}
            alt="Imagen de muestra de la web"
          />
          <div className='content-text-homepage'>
            <h1>
              Bienvenido a Donuts World.
            </h1>
            <h2>Aqui podrás dar rienda suelta a tu
              imaginación y crear la rosquilla de la felicidad que más te guste. El único límite es tu imaginación.</h2>
            <h2>Disfruta todo lo que puedas y... ¡Buen provecho!</h2>
          </div>
        </div>
      )}
      <FooterComponent/>
    </div>
  );
};

export default HomePage;
