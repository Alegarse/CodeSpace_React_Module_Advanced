import React from 'react';

const ContactPage = () => {
  return (
    <div className="container-contact">
      <h1>Donuts World</h1>
      <div className='text-map'>
        <div className="info-contact">
        <p>
          <b>Dirección: </b>Calle Azucar 123, 29631, Benalmádena, Málaga
        </p>
        <p>
          <b>Teléfono: </b>+34 644 321 368
        </p>
      </div>
      <iframe
        src="https://www.google.com/maps/embed?pb=!1m17!1m12!1m3!1d5387.183784234356!2d-4.554722950046574!3d36.59656108160192!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m2!1m1!2s!5e0!3m2!1ses!2ses!4v1751654201183!5m2!1ses!2ses"
        width="400"
        height="300"
        style={{border:0, borderRadius: '10px'}}
        allowFullscreen
        loading="lazy"
        referrerpolicy="no-referrer-when-downgrade"
      ></iframe>
      </div>
    </div>
  );
};

export default ContactPage;
