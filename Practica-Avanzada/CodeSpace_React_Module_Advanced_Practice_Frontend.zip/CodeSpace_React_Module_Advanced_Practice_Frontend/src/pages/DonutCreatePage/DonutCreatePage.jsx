import React, { useEffect } from 'react';
import DonutComponent from '../../components/DonutComponent/DonutComponent';
import { useDispatch } from 'react-redux';
import { donutInfoMode } from '../../components/DonutComponent/DonutComponentActions';

const DonutCreatePage = () => {

  const dispatch = useDispatch()
  
  const gotToCreateMode = () => {
    dispatch(
      donutInfoMode({
        infoMode: 'CREATE',
      })
    );
  };

  useEffect(() => {
    gotToCreateMode();
  }, []);

  return (
    <div className="container-create">
      <DonutComponent />
    </div>
  );
};

export default DonutCreatePage;
