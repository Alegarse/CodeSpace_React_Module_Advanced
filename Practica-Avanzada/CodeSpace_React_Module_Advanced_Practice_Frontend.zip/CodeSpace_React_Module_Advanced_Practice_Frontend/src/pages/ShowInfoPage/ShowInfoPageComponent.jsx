import ListingComponent from '../../components/ListingComponent/ListingComponent';
import { useSelector } from 'react-redux';
import DonutComponent from '../../components/DonutComponent/DonutComponent';

const ShowInfoPageComponent = () => {
  
  const { donutIdSelected } = useSelector(
    (state) => state.listingDonutsReducer
  );

  return (
    <div>
      {!donutIdSelected ? (
        <ListingComponent />
      ) : (
        <div>
          <DonutComponent />
        </div>
      )}
    </div>
  );
};

export default ShowInfoPageComponent;
