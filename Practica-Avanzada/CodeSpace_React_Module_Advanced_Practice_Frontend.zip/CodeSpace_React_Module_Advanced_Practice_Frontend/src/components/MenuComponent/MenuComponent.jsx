import React from 'react';
import { useDispatch } from 'react-redux';
import { changeMenuOptionActions } from './MenuComponentActions';
import logo from "../../assets/logo.png"
import { selectDonut } from '../ListingComponent/ListingComponentActions';
import { donutInfoMode } from '../DonutComponent/DonutComponentActions';

const MenuComponent = () => {
  const dispatch = useDispatch();

  const handlerMenuOption = (option) => {
    dispatch(
      changeMenuOptionActions({
        menuOption: option,
      })
    );
  };

  const resetValues = () => {
      dispatch(
        selectDonut({
          donutIdSelected: undefined,
        })
      );
      dispatch(
        donutInfoMode({
          infoMode: 'DETAILS',
        })
      );
    };

  return (
    <div className="menu-container">
      <img src={logo} alt="Logo de la empresa" title='Elevando el donut a otro nivel' onClick={() => handlerMenuOption(undefined)}/>
      <div className="buttons-menu-container">
        <div>
          <button className="btn-create" title='Pulse para agregar un nuevo donut' onClick={() => handlerMenuOption(0)}>
            Crear Donut
          </button>
        </div>
        <div>
          <button className="btn-listing" title='Pulse para ver el listado de donuts disponibles' onClick={() => {handlerMenuOption(1);resetValues()}}>
            Ver listado
          </button>
        </div>
        <div>
          <button className="btn-contact" title='Pulse para acceder a la página de contacto' onClick={() => handlerMenuOption(2)}>
            Contacto
          </button>
        </div>
      </div>
    </div>
  );
};

export default MenuComponent;
