export const CHANGE_MENU_OPTION = 'CHANGE_MENU_OPTION';

export const changeMenuOptionActions = (payload) => {
  return {
    type: CHANGE_MENU_OPTION,
    payload,
  };
};
