
export const LOAD_DONUTS = 'LOAD_DONUTS'
export const SELECT_DONUT = "SELECT_DONUT"

export const loadDonutsActions = (payload) => {
    return {
        type: LOAD_DONUTS,
        payload
    }
}

export const selectDonut = (payload) => {
  return {
    type: SELECT_DONUT,
    payload
  };
};