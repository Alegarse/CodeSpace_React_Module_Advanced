import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { getAllDonuts } from '../../core/services/donutFetch';
import { loadDonutsActions, selectDonut } from './ListingComponentActions';
import img_donut_unavaliable from '../../assets/img_donut_unavaliable.png';
import back_arrow from "../../assets/back.png"
import { changeMenuOptionActions } from '../MenuComponent/MenuComponentActions';

const ListingComponent = () => {
  const dispatch = useDispatch();
  const {donuts: donutsList} = useSelector((state) => state.listingDonutsReducer);

  const loadDonuts = async () => {
    const aux = await getAllDonuts();
    dispatch(
      loadDonutsActions({
        donuts: aux.data,
      })
    );
  };

  const selectDonutHandlertoDetails = (idDonut) => {
    dispatch(selectDonut({
      donutIdSelected: idDonut}))
  };


  const gotToHomePage = () => {
    dispatch(
      changeMenuOptionActions({
        menuOption: undefined,
      })
    )
  }

  useEffect(() => {
    loadDonuts();
  }, []);

  return (
    <div className='container-listing'>
      <div className='header-listing'>
        <h2 className='title-listing' title='¿A que esperas? ¡¡Date un capricho!!'>Listado de donuts disponibles</h2>
        <img className='btn-home' onClick={gotToHomePage} src={back_arrow} alt="Flecha de volver atrás" title='Pulse para volver a la home' />
      </div>      
      {!donutsList ? (
        <div>Cargando datos...</div>
      ) : donutsList.length <= 0 ? (
        <div>No existen donuts en la base de datos</div>
      ) : (
        donutsList.map((d, idx) => (
            <div className='card-list'
              key={idx}
            >
              <div>
                <img
                  src={d.imageUrl === '' ? img_donut_unavaliable : d.imageUrl}
                  alt=""
                />
              </div>
              <div className='text-card'>
                <div>Identificador: <span>{d._id}</span></div>
                <div>Nombre: <span>{d.title}</span></div>
              </div>
              <button className='btn-details' title='Pulse para visualizar los detalles del donut' onClick={() => selectDonutHandlertoDetails(d._id)}>Detalles</button>
            </div>
        ))
      )}
    </div>
  );
};

export default ListingComponent;
