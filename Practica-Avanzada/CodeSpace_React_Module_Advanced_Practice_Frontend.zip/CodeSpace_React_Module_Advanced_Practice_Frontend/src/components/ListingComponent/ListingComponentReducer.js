import { LOAD_DONUTS, SELECT_DONUT } from './ListingComponentActions';

const initialState = {
  donuts: undefined,
  donutIdSelected: undefined,
};

const listingDonutsReducer = (state = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case LOAD_DONUTS:
      return {
        ...state,
        donuts: payload.donuts,
      };
    case SELECT_DONUT:
      return {
        ...state,
        donutIdSelected: payload.donutIdSelected,
      };
    default:
      return state;
  }
};

export default listingDonutsReducer;
