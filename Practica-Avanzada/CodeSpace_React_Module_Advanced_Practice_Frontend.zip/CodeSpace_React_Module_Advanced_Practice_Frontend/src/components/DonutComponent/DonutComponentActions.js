export const LOAD_DONUT_DETAILS = 'LOAD_DONUT_DETAILS'
export const INFO_MODE = "INFO_MODE"
export const SELECT_DONUT_ID = "SELECT_DONUT_ID"

export const donutLoadActions = (payload) => {
    return {
        type: LOAD_DONUT_DETAILS,
        payload
    }
}

export const donutInfoMode = (payload) => {
    return {
        type: INFO_MODE,
        payload
    }
}

export const donutSelectId = (payload) => {
    return {
        type: SELECT_DONUT_ID,
        payload
    }
}