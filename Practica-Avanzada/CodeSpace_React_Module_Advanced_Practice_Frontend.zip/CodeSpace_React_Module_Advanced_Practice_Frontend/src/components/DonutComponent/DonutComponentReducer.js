import {
  INFO_MODE,
  LOAD_DONUT_DETAILS,
  SELECT_DONUT_ID,
} from './DonutComponentActions';

const initialState = {
  donut: undefined,
  infoMode: 'DETAILS',
  donutDetailsId: undefined,
};

const donutComponentReducer = (state = initialState, action) => {
  const { type, payload } = action;

  switch (type) {
    case LOAD_DONUT_DETAILS:
      return {
        ...state,
        donut: payload.donut,
      };
    case INFO_MODE:
      return {
        ...state,
        infoMode: payload.infoMode,
      };
    case SELECT_DONUT_ID:
      return {
        ...state,
        donutDetailsId: payload.donutDetailsId,
      };
    default:
      return state;
  }
};

export default donutComponentReducer;
