import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { changeMenuOptionActions } from '../MenuComponent/MenuComponentActions';
import back_arrow from '../../assets/back.png';
import {
  createNewDonut,
  deleteDonutById,
  getDonutById,
  updateDonutById,
} from '../../core/services/donutFetch';
import { donutInfoMode, donutLoadActions } from './DonutComponentActions';
import { selectDonut } from '../ListingComponent/ListingComponentActions';
import img_donut_unavaliable from '../../assets/img_donut_unavaliable.png';
import { convertDate } from '../../utils/functions';

const DonutComponent = () => {
  const dispatch = useDispatch();

  const [newDonut, setNewDonut] = useState({});

  const { donutIdSelected } = useSelector(
    (state) => state.listingDonutsReducer
  );
  const { donut, infoMode } = useSelector(
    (state) => state.donutComponentReducer
  );

  const loadDonutById = async () => {
    const aux = await getDonutById(donutIdSelected);
    dispatch(
      donutLoadActions({
        donut: aux.data,
      })
    );
  };

  const goToEditDonut = () => {
    dispatch(
      donutInfoMode({
        infoMode: 'EDIT',
      })
    );
    setNewDonut({ ...donut });
  };

  const cancelEdit = () => {
    dispatch(
      donutInfoMode({
        infoMode: 'DETAILS',
      })
    );
    setNewDonut({});
  };

  const donutHandler = (propName, propValue) => {
    setNewDonut({
      ...newDonut,
      [propName]: propValue,
    });
  };

  const deleteDonut = async () => {
    await deleteDonutById(donutIdSelected);
    goToHomePage();
  };

  const updateDonut = async () => {
    await updateDonutById(donutIdSelected, newDonut);
    dispatch(
      donutLoadActions({
        donut: newDonut,
      })
    );
    dispatch(
      donutInfoMode({
        infoMode: 'DETAILS',
      })
    );
  };

  const createDonut = async () => {
    await createNewDonut(newDonut);
    dispatch(
      changeMenuOptionActions({
        menuOption: 1,
      })
    );
  };

  const goToHomePage = () => {
    dispatch(
      changeMenuOptionActions({
        menuOption: undefined,
      })
    );
    dispatch(
      selectDonut({
        donutIdSelected: undefined,
      })
    );
  };

  const validateFields = (donut) => {
    let isError = false;
    let errorMessage = '';
    if (!donut.title || donut.title === '') {
      errorMessage = 'El nombre no puede estar vacio';
      isError = true;
    } else if (!donut.flavour || donut.flavour === '') {
      errorMessage = 'El sabor no puede estar vacío';
      isError = true;
    } else if (!donut.price || donut.price === '') {
      errorMessage = 'El precio no puede estar vacio';
      isError = true;
    }
    if (isError) {
      showError(errorMessage);
    } else {
      if (infoMode === 'CREATE') {
        createDonut();
      } else {
        updateDonut();
      }
    }
  };

  const showError = (message) => {
    const error = document.querySelector('.error_message');
    error.style.visibility = 'visible';
    error.textContent = message;
    setTimeout(() => {
      error.style.visibility = 'hidden';
    }, 2000);
  };

  useEffect(() => {
    loadDonutById();
  }, []);

  return (
    <div className="container-details">
      {infoMode === 'DETAILS' ? (
        <div>
          {!donut ? (
            <div>Cargando datos...</div>
          ) : (
            <>
              <div className="header-details">
                <h2 className="title-details">
                  Detalles e informacion del {donut.title}
                </h2>
                <img
                  className="btn-home"
                  onClick={goToHomePage}
                  src={back_arrow}
                  alt="Flecha de volver atrás"
                  title="Pulse para volver a la home"
                />
              </div>
              <div className="card-list-details">
                <div>
                  <img
                    src={
                      donut.imageUrl === ''
                        ? img_donut_unavaliable
                        : donut.imageUrl
                    }
                    alt=""
                  />
                </div>
                <div className="text-card-details">
                  <div>
                    Identificador: <span>{donut._id}</span>
                  </div>
                  <div>
                    Nombre: <span>{donut.title}</span>
                  </div>
                  <div>
                    Sabor: <span>{donut.flavour}</span>
                  </div>
                  <div>
                    Precio: <span>{donut.price}</span>
                  </div>
                  <div>
                    Disponible desde:{' '}
                    <span>{convertDate(donut.creationDate)}</span>
                  </div>
                </div>
                <div className="buttons-details">
                  <button className='btn-edit' onClick={goToEditDonut}>Editar</button>
                  <button className='btn-delete' onClick={deleteDonut}>Eliminar</button>
                </div>
              </div>
            </>
          )}
        </div>
      ) : (
        <div className="container-create">
          <h2 className="title-form">
            {infoMode === 'EDIT'
              ? `Edición del donut ${donut.title}`
              : 'Creación de un nuevo donut'}
          </h2>
          <div className="container-edit-create">
            <div className="input-cont">
              <span>Nombre del donut: </span>
              {infoMode === 'CREATE' ? (
                <input
                  type="text"
                  onChange={(e) => donutHandler('title', e.target.value)}
                />
              ) : (
                <input
                  type="text"
                  value={newDonut?.title || ''}
                  onChange={(e) => donutHandler('title', e.target.value)}
                />
              )}
            </div>
            <div className="input-cont">
              <span>Sabor del donut: </span>
              {infoMode === 'CREATE' ? (
                <input
                  type="text"
                  onChange={(e) => donutHandler('flavour', e.target.value)}
                />
              ) : (
                <input
                  type="text"
                  value={newDonut?.flavour || ''}
                  onChange={(e) => donutHandler('flavour', e.target.value)}
                />
              )}
            </div>
            <div className="input-cont">
              <span>Precio: </span>
              {infoMode === 'CREATE' ? (
                <input
                  type="number"
                  onChange={(e) => donutHandler('price', e.target.value)}
                />
              ) : (
                <input
                  type="number"
                  value={newDonut?.price || ''}
                  onChange={(e) => donutHandler('price', e.target.value)}
                />
              )}
            </div>
            <div className='buttons-edit-container'>
              {infoMode === 'CREATE' ? (
                <button
                  className="btn-create"
                  onClick={() => {
                    validateFields(newDonut);
                  }}
                >
                  Crear donut
                </button>
              ) : (
                <>
                  <button
                    className="btn-save"
                    onClick={() => {
                      validateFields(newDonut);
                    }}
                  >
                    Guardar cambios
                  </button>
                  <button className='btn-cancel' onClick={cancelEdit}>Cancelar</button>
                </>
              )}
            </div>
            <div className="error_message"></div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DonutComponent;
