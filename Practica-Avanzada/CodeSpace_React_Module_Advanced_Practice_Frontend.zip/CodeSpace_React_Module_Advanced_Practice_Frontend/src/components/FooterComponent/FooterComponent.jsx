import React from 'react'
import logo_ags from "../../assets/logo_ags.webp"
import linkedin from "../../assets/linkedin.png"
import github from "../../assets/github.png"

const FooterComponent = () => {
  return (
    <div className='footer-container'>
        <div className="footer-data-author">
        <div className="footer-logo">
          <img
            src={logo_ags}
            alt="Logo diseñado del autor"
            className="logo"
          />
          <p className="footer-author-name">Alejandro García Serrano</p>
        </div>
      </div>
      <p className="footer-author-copyright" title="Todos los derechos reservados">© Copyright 2025. Designed by <a href="https://www.arenalsoft.es" target='_blank'>arenalsoft.es</a> </p>
      <div className='refs'><a href="https://www.linkedin.com/in/alegarse/"  target='_blank'><img src={linkedin} alt="Enlace a Linkedin" /></a><a href="https://github.com/Alegarse"  target='_blank'><img src={github} alt="Enlace a Github" /></a></div>
    
    </div>
  )
}

export default FooterComponent