import { combineReducers } from "redux";
import menuComponentReducer from "../../../components/MenuComponent/MenuComponentReducer";
import listingDonutsReducer from "../../../components/ListingComponent/ListingComponentReducer";
import donutComponentReducer from "../../../components/DonutComponent/DonutComponentReducer";

const reducer = combineReducers({
    menuComponentReducer,
    listingDonutsReducer,
    donutComponentReducer
})

export default reducer