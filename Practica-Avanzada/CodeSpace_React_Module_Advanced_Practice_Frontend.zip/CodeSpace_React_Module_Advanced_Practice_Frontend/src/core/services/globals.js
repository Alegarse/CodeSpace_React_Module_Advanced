const globals = {
    URL_BASE: "http://localhost:3000/api"
}

export default globals