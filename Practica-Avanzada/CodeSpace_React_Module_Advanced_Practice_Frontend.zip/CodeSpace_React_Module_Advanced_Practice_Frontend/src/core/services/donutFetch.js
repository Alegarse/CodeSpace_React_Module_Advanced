import globals from './globals';

export const getAllDonuts = async () => {
  const data = await fetch(`${globals.URL_BASE}/donuts`, {
    method: 'GET',
  });
  const response = await data.json();
  return response;
};

export const getDonutById = async (donutId) => {
  const data = await fetch(`${globals.URL_BASE}/donuts/${donutId}`, {
    method: 'GET',
  });
  const response = await data.json();
  return response;
};

export const deleteDonutById = async (donutId) => {
  const data = await fetch(`${globals.URL_BASE}/donuts/${donutId}`, {
    method: 'DELETE',
  });
  const response = await data.json();
  return response;
};

export const updateDonutById = async (donutId, dataDonut) => {
  const data = await fetch(`${globals.URL_BASE}/donuts/${donutId}`, {
    method: 'PATCH',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(dataDonut),
  });
  const response = await data.json();
  return response;
};

export const createNewDonut = async (dataDonut) => {
  const data = await fetch(`${globals.URL_BASE}/donuts`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(dataDonut),
  });
  const response = await data.json();
  console.log(response)
  return response;
};
