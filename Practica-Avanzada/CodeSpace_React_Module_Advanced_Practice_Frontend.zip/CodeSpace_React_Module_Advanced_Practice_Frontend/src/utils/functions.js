export function convertDate(dateIso) {
    const f = new Date(dateIso);
    const dia = String(f.getDate()).padStart(2, "0")
    const mes = String(f.getMonth() + 1).padStart(2, "0")
    const año = f.getFullYear()

    return `${dia}-${mes}-${año}`
}