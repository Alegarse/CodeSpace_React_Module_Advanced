const donutModel = require("../models/donutModel")

const addDonuts = async (req, res) => {
  try {
    const donuts = req.body;
    await donutModel.insertMany(donuts);
    res.status(200).send("Los donuts se han guardado correctamente");
  } catch (error) {
    res.status(500).send({ status: "Failed", message: error.message });
  }
};

const getAllDonuts = async (req, res) => {
  try {
    const donuts = await donutModel.aggregate([
      {
        $project: {
          _id: 1,
          title: 1,
          flavour: 1,
          imageUrl: 1,
          price: 1,
          creationDate: 1,
          updateDate: 1,
        },
      },
    ]);
    if (!donuts) {
      return res.status(200).send("No se encuentra ningun donut");
    }
    res.status(200).send({ status: "Success", data: donuts });
  } catch (error) {
    res.status(500).send({ status: "Failed", message: error.message });
  }
};

const getDonutById = async (req,res) => {
  try {
    const { idDonut } = req.params;
    const donut = await donutModel.findById(idDonut);
    if (!donut) {
      return res.status(200).send("No se encuentra ningun donut por ese Id");
    }
    res.status(200).send({ status: "Success", data: donut });
  } catch (error) {
    res.status(500).send({ status: "Failed", message: error.message });
  }
}

const deleteDonutById = async (req, res) => {
  try {
    const { idDonut } = req.params;
    const deleteDonut = await donutModel.findByIdAndDelete(idDonut);
    if (!deleteDonut) {
      return res.status(200).send("No existe ningun donut con ese Id");
    }
    res
      .status(200)
      .send({ status: "Success", message: "El donut se ha eliminado" });
  } catch (error) {
    res.status(500).send({ status: "Failed", message: error.message });
  }
};

const updateDonutById = async (req, res) => {
  try {
    const { idDonut } = req.params;
    const newDonut = req.body;
    const updateDonut = await donutModel.findByIdAndUpdate(
      idDonut,
      newDonut,
      {
        new: true,
        runValidators: true,
      }
    );
    if (!updateDonut) {
      return res.status(200).send("No existe ningun donut con ese Id");
    }
    res
      .status(200)
      .send({ status: "Success", message: "El donut se ha modificado" });
  } catch (error) {
    res.status(500).send({ status: "Failed", message: error.message });
  }
};

const addDonut = async (req, res) => {
  try {
    const newDonut = req.body;
    await donutModel.create(newDonut);
    res.status(200).send("El donut se ha guardado correctamente");
  } catch (error) {
    res.status(500).send({ status: "Failed", message: error.message });
  }
};

module.exports = {
    addDonuts,
    getAllDonuts,
    getDonutById,
    deleteDonutById,
    updateDonutById,
    addDonut
}