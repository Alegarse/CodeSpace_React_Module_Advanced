const express = require('express');
const { getAllDonuts, addDonuts, getDonutById, deleteDonutById, updateDonutById, addDonut } = require('../controllers/donutsController');

const router = express.Router();

//router.post("/", addDonuts); // Add donuts to BBDD [Only for proyect init purposes]
router.get('/', getAllDonuts); 
router.get('/:idDonut', getDonutById);
router.delete("/:idDonut", deleteDonutById);
router.patch("/:idDonut", updateDonutById);
router.post("/", addDonut);

module.exports = router;
