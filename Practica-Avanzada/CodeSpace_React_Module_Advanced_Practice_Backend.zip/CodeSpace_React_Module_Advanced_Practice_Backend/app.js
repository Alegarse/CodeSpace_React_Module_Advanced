const PORT = 3000;
const express = require('express');
const cors = require("cors")
const donutsRouter = require('./routes/donutsRouter');

require('dotenv').config();

const connectDatabase = require('./db/connect');

const app = express();

app.use(express.json());
app.use(cors());

connectDatabase();

//Router for donuts
app.use('/api/donuts', donutsRouter);

app.listen(PORT, () => {
  console.log(`Servidor ejecutandose en http://localhost:${PORT}`);
});
