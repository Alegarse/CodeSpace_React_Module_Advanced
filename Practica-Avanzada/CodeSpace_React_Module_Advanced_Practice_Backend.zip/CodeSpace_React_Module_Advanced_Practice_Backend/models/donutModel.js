const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const schemaDonut = new Schema({
  title: {
    type: String,
    required: [true, "El nombre del donut es obligatorio"],
  },
  flavour: {
    type: String,
    required: [true, "El sabor del donut es obligatorio"],
  },
  price: {
    type: Number,
    required: [true, "El precio del donut es obligatorio"],
  },
  imageUrl: {
    type: String,
    default: "",
  },
  creationDate: {
    type: Date,
    default: Date.now,
  },
  updateDate: {
    type: Date,
    default: Date.now,
  },
});

const donutModel = mongoose.model("donut", schemaDonut, "donuts");
module.exports = donutModel;
